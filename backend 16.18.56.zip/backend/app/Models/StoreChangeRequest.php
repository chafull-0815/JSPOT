<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StoreChangeRequest extends Model
{
    /** @use HasFactory<\Database\Factories\StoreChangeRequestFactory> */
    use HasFactory;
}
