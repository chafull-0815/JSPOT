<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use app\Providers\Illuminate\Foundation\Support\Providers\RouteServiceProvider;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\wp_authenticateUsers;


class AdminController extends Controller
{

}
